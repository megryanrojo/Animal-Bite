<?php
header("Location: /src/login/admin_login.php");
exit();
?>


